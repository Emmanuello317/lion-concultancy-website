LION CONSULTANCY SERVICES AND TRAVEL — WEBSITE PACKAGE

Files:
- index.html: website content
- styles.css: responsive design for phones, tablets and computers
- script.js: mobile navigation and enquiry form
- assets/lion-mark.svg: logo artwork

DEPLOY TO NETLIFY (FREE):
1. Extract this ZIP file on your computer or phone.
2. Open https://app.netlify.com/drop in a browser and sign in or create a Netlify account.
3. Upload/drag the extracted website folder (the folder containing index.html) into the Netlify Drop area. If your phone browser does not support folder upload, use a computer or a file manager/browser combination that supports folder upload.
4. Wait for deployment and open the generated *.netlify.app URL.
5. In Netlify site settings, you can change the site name if the desired name is available.

IMPORTANT:
- This is a static website package; it has not been published online by this ZIP creation step.
- The contact form opens the visitor's email application with a draft addressed to lionconsultancy.recruitment@gmail.com. It does not send or store messages automatically.
- No custom domain is included. A free Netlify subdomain is provided by Netlify.
- Please verify all company details, legal/licence information, and contact information before publishing.
