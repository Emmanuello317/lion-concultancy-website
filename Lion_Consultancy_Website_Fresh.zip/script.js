const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('#main-nav');
menuButton?.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', String(open));
  menuButton.setAttribute('aria-label', open ? 'Close navigation menu' : 'Open navigation menu');
  menuButton.textContent = open ? '×' : '☰';
});
nav?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuButton?.setAttribute('aria-expanded', 'false');
  if (menuButton) { menuButton.textContent = '☰'; menuButton.setAttribute('aria-label', 'Open navigation menu'); }
}));
document.querySelector('#year').textContent = new Date().getFullYear();
document.querySelector('#contact-form')?.addEventListener('submit', event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const subject = `Website enquiry: ${form.get('topic')}`;
  const body = [
    `Name: ${form.get('name')}`,
    `Email: ${form.get('email')}`,
    `Company / organisation: ${form.get('organisation') || 'Not provided'}`,
    `Topic: ${form.get('topic')}`,
    '',
    'Message:',
    form.get('message')
  ].join('\n');
  const status = document.querySelector('#form-status');
  status.textContent = 'Your email app should open with the enquiry prepared. Please review it and press Send.';
  window.location.href = `mailto:lionconsultancy.recruitment@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
});